﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;

namespace dionishuesos
{
    public partial class MainWindow : Window
    {
        private readonly string saveFile = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "AppDock", "appdata.json");

        private readonly string shortcutsFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "AppDock", "Shortcuts");

        private readonly string iconsFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "AppDock", "Icons");

        private const string DefaultGearUrl =
            "https://upload.wikimedia.org/wikipedia/commons/9/96/Gear-icon-transparent-background.png";

        private const string DefaultCloseUrl =
            "https://images.icon-icons.com/2367/PNG/512/x_close_icon_143474.png";

        private string currentColor = "#202020";
        private string settingsImagePath = "";
        private string closeImagePath = "";
        private Dictionary<string, string> customIcons =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        private Button draggedButton = null;
        private int originalRow;
        private int originalColumn;
        private Point dragStartPoint;
        private bool isDragging = false;

        [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr SHGetFileInfo(
            string pszPath, uint dwFileAttributes, out SHFILEINFO psfi,
            uint cbFileInfo, uint uFlags);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool DestroyIcon(IntPtr hIcon);

        [DllImport("shell32.dll")]
        private static extern void SHChangeNotify(
            uint wEventId, uint uFlags, IntPtr dwItem1, IntPtr dwItem2);

        private const uint SHGFI_ICON = 0x000000100;
        private const uint SHGFI_LARGEICON = 0x000000000;
        private const uint SHCNE_UPDATEITEM = 0x00002000;
        private const uint SHCNE_ATTRIBUTES = 0x00000800;
        private const uint SHCNF_PATHW = 0x00000005;

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct SHFILEINFO
        {
            public IntPtr hIcon;
            public int iIcon;
            public uint dwAttributes;

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
            public string szDisplayName;

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)]
            public string szTypeName;
        }

        private class AppButtonData
        {
            public string ApplicationPath { get; set; } = "";
            public string ShortcutPath { get; set; } = "";
            public string StoredShortcutPath { get; set; } = "";
            public bool HiddenByAppDock { get; set; }
            public int OriginalAttributes { get; set; }
        }

        public MainWindow()
        {
            InitializeComponent();

            Directory.CreateDirectory(shortcutsFolder);
            Directory.CreateDirectory(iconsFolder);

            LoadData();
            EnsureDefaultInterfaceImages();
            RefreshInterfaceImages();
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DependencyObject source = e.OriginalSource as DependencyObject;

            if (IsInsideButton(source)) return;
            if (IsInsideElement(source, SettingsPanel)) return;

            try { DragMove(); } catch { }
        }

        private bool IsInsideButton(DependencyObject source)
        {
            while (source != null)
            {
                if (source is Button) return true;
                source = VisualTreeHelper.GetParent(source);
            }
            return false;
        }

        private bool IsInsideElement(DependencyObject source, DependencyObject parent)
        {
            while (source != null)
            {
                if (source == parent) return true;
                source = VisualTreeHelper.GetParent(source);
            }
            return false;
        }

        private void Window_DragOver(object sender, DragEventArgs e)
        {
            e.Effects = e.Data.GetDataPresent(DataFormats.FileDrop)
                ? DragDropEffects.Copy
                : DragDropEffects.None;
            e.Handled = true;
        }

        private void Window_Drop(object sender, DragEventArgs e)
        {
            if (!e.Data.GetDataPresent(DataFormats.FileDrop)) return;

            string[] paths = (string[])e.Data.GetData(DataFormats.FileDrop);
            foreach (string path in paths)
            {
                if (File.Exists(path) || Directory.Exists(path))
                    AddApplication(path);
            }
        }

        private bool IsOnDesktop(string path)
        {
            try
            {
                string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                string fullPath = Path.GetFullPath(path).TrimEnd(Path.DirectorySeparatorChar);
                string fullDesktop = Path.GetFullPath(desktop).TrimEnd(Path.DirectorySeparatorChar);

                return fullPath.Equals(fullDesktop, StringComparison.OrdinalIgnoreCase) ||
                       fullPath.StartsWith(fullDesktop + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
            }
            catch { return false; }
        }

        private int HideFromDesktop(string path)
        {
            try
            {
                FileAttributes attributes = File.GetAttributes(path);
                int original = (int)attributes;

                if ((attributes & FileAttributes.Hidden) != 0) return original;

                File.SetAttributes(path, attributes | FileAttributes.Hidden);
                RefreshExplorer(path);
                return original;
            }
            catch { return -1; }
        }

        private bool RestoreFromDesktop(string path, int originalAttributes)
        {
            try
            {
                if (!File.Exists(path) && !Directory.Exists(path)) return false;

                FileAttributes attributes = originalAttributes >= 0
                    ? (FileAttributes)originalAttributes
                    : File.GetAttributes(path);

                attributes &= ~FileAttributes.Hidden;
                File.SetAttributes(path, attributes);
                RefreshExplorer(path);
                return true;
            }
            catch { return false; }
        }

        private void RefreshExplorer(string path)
        {
            try
            {
                SHChangeNotify(SHCNE_ATTRIBUTES | SHCNE_UPDATEITEM, SHCNF_PATHW,
                    IntPtr.Zero, IntPtr.Zero);
            }
            catch { }
        }

        private void AddApplication(string path)
        {
            if (string.IsNullOrEmpty(path)) return;

            bool isFile = File.Exists(path);
            bool isDirectory = Directory.Exists(path);
            if (!isFile && !isDirectory) return;

            bool isShortcut = isFile && Path.GetExtension(path).Equals(".lnk", StringComparison.OrdinalIgnoreCase);

            string applicationPath = path;
            string shortcutPath = "";
            string storedShortcutPath = "";
            bool hiddenByAppDock = false;
            int originalAttributes = 0;

            if (isShortcut)
            {
                string resolvedPath = ResolveShortcut(path);
                if (string.IsNullOrEmpty(resolvedPath)) return;
                if (!File.Exists(resolvedPath) && !Directory.Exists(resolvedPath)) return;

                applicationPath = resolvedPath;
                shortcutPath = path;

                string storedName = Guid.NewGuid().ToString("N") + ".lnk";
                storedShortcutPath = Path.Combine(shortcutsFolder, storedName);

                try
                {
                    File.Move(path, storedShortcutPath);
                }
                catch
                {
                    MessageBox.Show("Не удалось перенести ярлык в AppDock.", "AppDock",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
            else if (IsOnDesktop(path))
            {
                int attributes = HideFromDesktop(path);
                if (attributes >= 0)
                {
                    hiddenByAppDock = true;
                    originalAttributes = attributes;
                }
            }

            AddApplicationFromData(applicationPath, GetDisplayName(path), -1, -1,
                shortcutPath, storedShortcutPath, hiddenByAppDock, originalAttributes);

            bool added = AppsPanel.Children.OfType<Button>().Any(button =>
            {
                AppButtonData data = GetButtonData(button);
                return data != null && string.Equals(data.ApplicationPath, applicationPath, StringComparison.OrdinalIgnoreCase);
            });

            if (!added)
            {
                if (hiddenByAppDock) RestoreFromDesktop(path, originalAttributes);
                if (isShortcut && File.Exists(storedShortcutPath)) RestoreShortcut(shortcutPath, storedShortcutPath);
                return;
            }

            SaveData();
        }

        private string GetDisplayName(string path)
        {
            try
            {
                string cleanPath = path.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                string name = Path.GetFileName(cleanPath);
                return string.IsNullOrEmpty(name) ? path : name;
            }
            catch { return path; }
        }

        private string ResolveShortcut(string shortcutPath)
        {
            try
            {
                Type shellType = Type.GetTypeFromProgID("WScript.Shell");
                if (shellType == null) return null;

                dynamic shell = Activator.CreateInstance(shellType);
                dynamic shortcut = shell.CreateShortcut(shortcutPath);
                return shortcut.TargetPath;
            }
            catch { return null; }
        }

        private bool RestoreShortcut(string originalPath, string storedPath)
        {
            try
            {
                if (string.IsNullOrEmpty(storedPath) || !File.Exists(storedPath)) return false;

                string destination = originalPath;
                if (string.IsNullOrEmpty(destination))
                {
                    destination = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),
                        Path.GetFileName(storedPath));
                }

                string directory = Path.GetDirectoryName(destination);
                if (string.IsNullOrEmpty(directory)) return false;
                Directory.CreateDirectory(directory);

                if (File.Exists(destination))
                {
                    string directoryPath = Path.GetDirectoryName(destination);
                    string fileName = Path.GetFileNameWithoutExtension(destination);
                    string extension = Path.GetExtension(destination);
                    int number = 2;
                    do
                    {
                        destination = Path.Combine(directoryPath, fileName + " (" + number + ")" + extension);
                        number++;
                    } while (File.Exists(destination));
                }

                Type shellType = Type.GetTypeFromProgID("WScript.Shell");
                if (shellType == null) return false;

                dynamic shell = Activator.CreateInstance(shellType);
                dynamic oldShortcut = shell.CreateShortcut(storedPath);
                dynamic newShortcut = shell.CreateShortcut(destination);

                newShortcut.TargetPath = oldShortcut.TargetPath;
                newShortcut.Arguments = oldShortcut.Arguments;
                newShortcut.WorkingDirectory = oldShortcut.WorkingDirectory;
                newShortcut.IconLocation = oldShortcut.IconLocation;
                newShortcut.Description = oldShortcut.Description;
                newShortcut.Save();

                if (!File.Exists(destination)) return false;
                File.Delete(storedPath);
                RefreshExplorer(destination);
                return true;
            }
            catch { return false; }
        }

        private AppButtonData GetButtonData(Button button) => button.Tag as AppButtonData;

        private void AddApplicationFromData(string file, string name, int row, int column,
            string shortcutPath = "", string storedShortcutPath = "",
            bool hiddenByAppDock = false, int originalAttributes = 0)
        {
            if (!File.Exists(file) && !Directory.Exists(file)) return;

            foreach (Button existingButton in AppsPanel.Children.OfType<Button>())
            {
                AppButtonData existingData = GetButtonData(existingButton);
                if (existingData != null && string.Equals(existingData.ApplicationPath, file, StringComparison.OrdinalIgnoreCase))
                    return;
            }

            Button appButton = CreateApplicationButton(file, name);
            appButton.Tag = new AppButtonData
            {
                ApplicationPath = file,
                ShortcutPath = shortcutPath,
                StoredShortcutPath = storedShortcutPath,
                HiddenByAppDock = hiddenByAppDock,
                OriginalAttributes = originalAttributes
            };

            if (row >= 0 && row < 3 && column >= 0 && column < 5 && GetButtonAtCell(row, column) == null)
            {
                Grid.SetRow(appButton, row);
                Grid.SetColumn(appButton, column);
                AppsPanel.Children.Add(appButton);
            }
            else
            {
                TryPlaceApplication(appButton);
            }

            AnimateAppear(appButton);
        }

        private Button CreateApplicationButton(string file, string name)
        {
            Button appButton = new Button
            {
                Width = 90,
                Height = 100,
                Margin = new Thickness(5),
                Style = (Style)FindResource("AppButtonStyle"),
                ToolTip = file
            };

            StackPanel content = new StackPanel
            {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };

            ImageSource customSource = GetCustomIconSource(file);
            if (customSource != null)
            {
                AddImageToPanel(content, customSource, 48, 48, 5);
            }
            else
            {
                SHFILEINFO shinfo;
                SHGetFileInfo(file, 0, out shinfo, (uint)Marshal.SizeOf(typeof(SHFILEINFO)),
                    SHGFI_ICON | SHGFI_LARGEICON);

                if (shinfo.hIcon != IntPtr.Zero)
                {
                    try
                    {
                        ImageSource icon = Imaging.CreateBitmapSourceFromHIcon(
                            shinfo.hIcon, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
                        AddImageToPanel(content, icon, 48, 48, 5);
                    }
                    finally { DestroyIcon(shinfo.hIcon); }
                }
            }

            TextBlock text = new TextBlock
            {
                Text = name,
                Foreground = Brushes.White,
                FontSize = 12,
                TextAlignment = TextAlignment.Center,
                TextWrapping = TextWrapping.Wrap,
                MaxWidth = 85
            };

            content.Children.Add(text);
            appButton.Content = content;

            appButton.MouseDoubleClick += AppButton_MouseDoubleClick;
            appButton.MouseRightButtonUp += AppButton_MouseRightButtonUp;
            appButton.PreviewMouseLeftButtonDown += AppButton_MouseLeftButtonDown;
            appButton.PreviewMouseMove += AppButton_MouseMove;
            appButton.PreviewMouseLeftButtonUp += AppButton_MouseLeftButtonUp;

            return appButton;
        }

        private void AddImageToPanel(StackPanel panel, ImageSource source, double width, double height, double bottomMargin)
        {
            panel.Children.Add(new Image
            {
                Source = source,
                Width = width,
                Height = height,
                Margin = new Thickness(0, 0, 0, bottomMargin),
                Stretch = Stretch.Uniform
            });
        }

        private ImageSource GetCustomIconSource(string path)
        {
            if (customIcons.TryGetValue(path, out string iconPath) && File.Exists(iconPath))
                return LoadImage(iconPath);
            return null;
        }

        private BitmapImage LoadImage(string path)
        {
            try
            {
                BitmapImage image = new BitmapImage();
                image.BeginInit();
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.UriSource = new Uri(path, UriKind.Absolute);
                image.EndInit();
                image.Freeze();
                return image;
            }
            catch { return null; }
        }

        private void AppButton_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (isDragging) return;

            Button button = (Button)sender;
            AppButtonData data = GetButtonData(button);
            if (data == null || string.IsNullOrEmpty(data.ApplicationPath)) return;

            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = data.ApplicationPath,
                    UseShellExecute = true
                });
            }
            catch
            {
                MessageBox.Show("Не удалось открыть файл или папку.", "AppDock",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AppButton_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Button button = (Button)sender;
            if (e.ClickCount > 1) return;

            draggedButton = button;
            originalRow = Grid.GetRow(button);
            originalColumn = Grid.GetColumn(button);
            dragStartPoint = e.GetPosition(AppsPanel);
            isDragging = false;
            button.CaptureMouse();
            e.Handled = true;
        }

        private void AppButton_MouseMove(object sender, MouseEventArgs e)
        {
            if (draggedButton == null) return;

            Point currentPoint = e.GetPosition(AppsPanel);
            double deltaX = currentPoint.X - dragStartPoint.X;
            double deltaY = currentPoint.Y - dragStartPoint.Y;

            if (!isDragging)
            {
                if (Math.Abs(deltaX) < 5 && Math.Abs(deltaY) < 5) return;
                isDragging = true;
                draggedButton.Opacity = 0.75;
                Panel.SetZIndex(draggedButton, 100);
                draggedButton.BeginAnimation(OpacityProperty, null);
            }

            TranslateTransform translate = GetTranslateTransform(draggedButton);
            translate.X = deltaX;
            translate.Y = deltaY;

            int targetColumn = Math.Max(0, Math.Min(4, (int)(currentPoint.X / 100)));
            int targetRow = Math.Max(0, Math.Min(2, (int)(currentPoint.Y / 110)));
            HighlightCell(targetRow, targetColumn);
        }

        private void AppButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (draggedButton == null) return;

            Button button = draggedButton;
            button.ReleaseMouseCapture();

            if (isDragging)
            {
                Point currentPoint = e.GetPosition(AppsPanel);
                int targetColumn = Math.Max(0, Math.Min(4, (int)(currentPoint.X / 100)));
                int targetRow = Math.Max(0, Math.Min(2, (int)(currentPoint.Y / 110)));
                MoveApplication(button, targetRow, targetColumn);
            }

            TranslateTransform translate = GetTranslateTransform(button);
            DoubleAnimation returnX = new DoubleAnimation
            {
                To = 0,
                Duration = TimeSpan.FromMilliseconds(160),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            DoubleAnimation returnY = new DoubleAnimation
            {
                To = 0,
                Duration = TimeSpan.FromMilliseconds(160),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };

            translate.BeginAnimation(TranslateTransform.XProperty, returnX);
            translate.BeginAnimation(TranslateTransform.YProperty, returnY);
            button.Opacity = 1;
            Panel.SetZIndex(button, 1);
            ClearCellHighlight();
            draggedButton = null;
            isDragging = false;
            SaveData();
            e.Handled = true;
        }

        private TranslateTransform GetTranslateTransform(Button button)
        {
            TransformGroup group = button.RenderTransform as TransformGroup;
            if (group == null)
            {
                group = new TransformGroup();
                group.Children.Add(new ScaleTransform(1, 1));
                group.Children.Add(new TranslateTransform(0, 0));
                button.RenderTransform = group;
            }

            TranslateTransform translate = group.Children.OfType<TranslateTransform>().FirstOrDefault();
            if (translate == null)
            {
                translate = new TranslateTransform(0, 0);
                group.Children.Add(translate);
            }
            return translate;
        }

        private void MoveApplication(Button button, int targetRow, int targetColumn)
        {
            int oldRow = Grid.GetRow(button);
            int oldColumn = Grid.GetColumn(button);
            if (oldRow == targetRow && oldColumn == targetColumn) return;

            Button otherButton = GetButtonAtCell(targetRow, targetColumn);
            if (otherButton != null && otherButton != button)
            {
                Grid.SetRow(otherButton, oldRow);
                Grid.SetColumn(otherButton, oldColumn);
                AnimateMove(otherButton);
            }

            Grid.SetRow(button, targetRow);
            Grid.SetColumn(button, targetColumn);
            AnimateMove(button);
        }

        private void AnimateMove(Button button)
        {
            button.Opacity = 0.7;
            button.BeginAnimation(OpacityProperty, new DoubleAnimation
            {
                From = 0.7,
                To = 1,
                Duration = TimeSpan.FromMilliseconds(180),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            });
        }

        private void HighlightCell(int row, int column)
        {
            Grid.SetRow(DropHighlight, row);
            Grid.SetColumn(DropHighlight, column);

            if (DropHighlight.Visibility != Visibility.Visible)
            {
                DropHighlight.Visibility = Visibility.Visible;
                DropHighlight.BeginAnimation(OpacityProperty, new DoubleAnimation
                {
                    From = 0,
                    To = 1,
                    Duration = TimeSpan.FromMilliseconds(120)
                });
            }
        }

        private void ClearCellHighlight()
        {
            DoubleAnimation fadeOut = new DoubleAnimation
            {
                From = DropHighlight.Opacity,
                To = 0,
                Duration = TimeSpan.FromMilliseconds(120)
            };
            fadeOut.Completed += (s, e) => DropHighlight.Visibility = Visibility.Collapsed;
            DropHighlight.BeginAnimation(OpacityProperty, fadeOut);
        }

        private Button GetButtonAtCell(int row, int column)
        {
            foreach (Button button in AppsPanel.Children.OfType<Button>())
            {
                if (button == draggedButton) continue;
                if (Grid.GetRow(button) == row && Grid.GetColumn(button) == column) return button;
            }
            return null;
        }

        private void TryPlaceApplication(Button button)
        {
            for (int row = 0; row < 3; row++)
            {
                for (int column = 0; column < 5; column++)
                {
                    if (GetButtonAtCell(row, column) == null)
                    {
                        Grid.SetRow(button, row);
                        Grid.SetColumn(button, column);
                        AppsPanel.Children.Add(button);
                        return;
                    }
                }
            }
        }

        private void AnimateAppear(Button button)
        {
            button.Opacity = 0;
            button.BeginAnimation(OpacityProperty, new DoubleAnimation
            {
                From = 0,
                To = 1,
                Duration = TimeSpan.FromMilliseconds(200)
            });
        }

        private void AppButton_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            Button button = (Button)sender;
            AppButtonData data = GetButtonData(button);
            ContextMenu menu = new ContextMenu();

            MenuItem rename = new MenuItem { Header = "✏ Переименовать" };
            MenuItem delete = new MenuItem { Header = "🗑 Удалить" };

            rename.Click += (s, args) => StartRename(button);
            delete.Click += (s, args) => RemoveApplication(button);

            menu.Items.Add(rename);

            if (data != null && Path.GetExtension(data.ApplicationPath).Equals(".exe", StringComparison.OrdinalIgnoreCase))
            {
                MenuItem changeIcon = new MenuItem { Header = "🖼 Поменять иконку" };
                changeIcon.Click += (s, args) => ChangeApplicationIcon(button);
                menu.Items.Add(changeIcon);
            }

            menu.Items.Add(new Separator());
            menu.Items.Add(delete);
            menu.IsOpen = true;
            e.Handled = true;
        }

        private void StartRename(Button button)
        {
            if (!(button.Content is StackPanel panel)) return;

            TextBlock oldText = panel.Children.OfType<TextBlock>().FirstOrDefault();
            if (oldText == null) return;

            TextBox textBox = new TextBox
            {
                Text = oldText.Text,
                Width = 85,
                Height = 30,
                FontSize = 12,
                TextAlignment = TextAlignment.Center
            };

            panel.Children.Remove(oldText);
            panel.Children.Add(textBox);
            textBox.Focus();
            textBox.SelectAll();

            bool saved = false;
            void SaveRename()
            {
                if (saved) return;
                saved = true;

                string newName = textBox.Text.Trim();
                if (string.IsNullOrWhiteSpace(newName)) newName = oldText.Text;

                panel.Children.Remove(textBox);
                oldText.Text = newName;
                panel.Children.Add(oldText);
                SaveData();
            }

            textBox.KeyDown += (s, e) =>
            {
                if (e.Key == Key.Enter) SaveRename();
                else if (e.Key == Key.Escape)
                {
                    saved = true;
                    panel.Children.Remove(textBox);
                    panel.Children.Add(oldText);
                }
            };
            textBox.LostFocus += (s, e) => SaveRename();
        }

        private void RemoveApplication(Button button)
        {
            AppButtonData buttonData = GetButtonData(button);
            DoubleAnimation animation = new DoubleAnimation
            {
                From = 1,
                To = 0,
                Duration = TimeSpan.FromMilliseconds(180)
            };

            animation.Completed += (s, e) =>
            {
                bool success = true;

                if (buttonData != null && !string.IsNullOrEmpty(buttonData.StoredShortcutPath))
                {
                    success = RestoreShortcut(buttonData.ShortcutPath, buttonData.StoredShortcutPath);
                }
                else if (buttonData != null && buttonData.HiddenByAppDock)
                {
                    success = RestoreFromDesktop(buttonData.ApplicationPath, buttonData.OriginalAttributes);
                }

                if (success)
                {
                    AppsPanel.Children.Remove(button);
                    SaveData();
                }
                else
                {
                    button.Opacity = 1;
                    SaveData();
                    MessageBox.Show("Не удалось вернуть объект на рабочий стол.", "AppDock",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            };

            button.BeginAnimation(OpacityProperty, animation);
        }

        private void ChangeApplicationIcon(Button button)
        {
            AppButtonData data = GetButtonData(button);
            if (data == null) return;

            string selected = PickImageWithPreview("Выберите иконку для EXE", GetCustomIconPath(data.ApplicationPath));
            if (string.IsNullOrEmpty(selected)) return;

            string stored = CopyIconToAppData(selected, "app");
            if (string.IsNullOrEmpty(stored)) return;

            customIcons[data.ApplicationPath] = stored;
            RebuildApplicationButton(button);
            SaveData();
        }

        private string GetCustomIconPath(string applicationPath)
        {
            return customIcons.TryGetValue(applicationPath, out string path) && File.Exists(path)
                ? path : "";
        }

        private void RebuildApplicationButton(Button oldButton)
        {
            int row = Grid.GetRow(oldButton);
            int column = Grid.GetColumn(oldButton);
            AppButtonData data = GetButtonData(oldButton);
            if (data == null) return;

            string name = data.ApplicationPath;
            if (oldButton.Content is StackPanel panel)
            {
                TextBlock text = panel.Children.OfType<TextBlock>().FirstOrDefault();
                if (text != null) name = text.Text;
            }

            Button newButton = CreateApplicationButton(data.ApplicationPath, name);
            newButton.Tag = data;
            Grid.SetRow(newButton, row);
            Grid.SetColumn(newButton, column);

            int index = AppsPanel.Children.IndexOf(oldButton);
            AppsPanel.Children.RemoveAt(index);
            AppsPanel.Children.Insert(index, newButton);
            AnimateAppear(newButton);
        }

        private void OpenSettings_Click(object sender, RoutedEventArgs e)
        {
            SettingsPanel.Visibility = Visibility.Visible;
            RefreshInterfaceImages();
        }

        private void SaveSettings_Click(object sender, RoutedEventArgs e)
        {
            Title = FolderNameBox.Text;
            SettingsPanel.Visibility = Visibility.Collapsed;
            SaveData();
        }

        private void OpacitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (MainBorder != null) MainBorder.Opacity = OpacitySlider.Value;
        }

        private void DarkColor_Click(object sender, RoutedEventArgs e)
        {
            currentColor = "#202020";
            MainBorder.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#DD202020"));
        }

        private void GrayColor_Click(object sender, RoutedEventArgs e)
        {
            currentColor = "#505050";
            MainBorder.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#DD505050"));
        }

        private void LightColor_Click(object sender, RoutedEventArgs e)
        {
            currentColor = "#D0D0D0";
            MainBorder.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#DDD0D0D0"));
        }

        private void ChangeGearImage_Click(object sender, RoutedEventArgs e)
        {
            string selected = PickImageWithPreview("Выберите изображение для шестерёнки", settingsImagePath);
            if (string.IsNullOrEmpty(selected)) return;

            string stored = CopyIconToAppData(selected, "settings");
            if (string.IsNullOrEmpty(stored)) return;

            settingsImagePath = stored;
            RefreshInterfaceImages();
            SaveData();
        }

        private void ChangeCloseImage_Click(object sender, RoutedEventArgs e)
        {
            string selected = PickImageWithPreview("Выберите изображение для крестика", closeImagePath);
            if (string.IsNullOrEmpty(selected)) return;

            string stored = CopyIconToAppData(selected, "close");
            if (string.IsNullOrEmpty(stored)) return;

            closeImagePath = stored;
            RefreshInterfaceImages();
            SaveData();
        }

        private string PickImageWithPreview(string title, string initialPath)
        {
            Window picker = new Window
            {
                Title = title,
                Width = 420,
                Height = 410,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                ResizeMode = ResizeMode.NoResize,
                Background = new SolidColorBrush(Color.FromRgb(32, 32, 32))
            };

            Grid grid = new Grid { Margin = new Thickness(18) };
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            Border previewBorder = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(45, 45, 45)),
                CornerRadius = new CornerRadius(14),
                Padding = new Thickness(15)
            };

            Image preview = new Image { Stretch = Stretch.Uniform };
            if (!string.IsNullOrEmpty(initialPath) && File.Exists(initialPath))
                preview.Source = LoadImage(initialPath);
            previewBorder.Child = preview;
            Grid.SetRow(previewBorder, 0);
            grid.Children.Add(previewBorder);

            Button chooseButton = new Button
            {
                Content = "Выбрать файл",
                Height = 35,
                Margin = new Thickness(0, 12, 0, 8)
            };
            Grid.SetRow(chooseButton, 1);
            grid.Children.Add(chooseButton);

            StackPanel buttons = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right
            };

            Button cancelButton = new Button { Content = "Отмена", Width = 90, Height = 32, Margin = new Thickness(0, 0, 8, 0) };
            Button okButton = new Button { Content = "Сохранить", Width = 100, Height = 32, IsDefault = true };
            buttons.Children.Add(cancelButton);
            buttons.Children.Add(okButton);
            Grid.SetRow(buttons, 2);
            grid.Children.Add(buttons);

            string selectedPath = initialPath;
            chooseButton.Click += (s, e) =>
            {
                OpenFileDialog dialog = new OpenFileDialog
                {
                    Title = "Выберите изображение",
                    Filter = "Изображения|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.ico|Все файлы|*.*",
                    CheckFileExists = true
                };

                if (dialog.ShowDialog(picker) == true)
                {
                    BitmapImage image = LoadImage(dialog.FileName);
                    if (image != null)
                    {
                        selectedPath = dialog.FileName;
                        preview.Source = image;
                    }
                    else
                    {
                        MessageBox.Show("Не удалось открыть это изображение.", "AppDock",
                            MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
            };

            string result = null;
            okButton.Click += (s, e) =>
            {
                if (string.IsNullOrEmpty(selectedPath) || !File.Exists(selectedPath))
                {
                    MessageBox.Show("Сначала выберите изображение.", "AppDock",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                result = selectedPath;
                picker.DialogResult = true;
            };

            cancelButton.Click += (s, e) => picker.DialogResult = false;
            picker.Content = grid;
            picker.ShowDialog();
            return result;
        }

        private string CopyIconToAppData(string source, string prefix)
        {
            try
            {
                Directory.CreateDirectory(iconsFolder);
                string extension = Path.GetExtension(source);
                if (string.IsNullOrEmpty(extension)) extension = ".png";

                string destination = Path.Combine(
                    iconsFolder,
                    prefix + "_" + Guid.NewGuid().ToString("N") + extension);

                File.Copy(source, destination, true);
                return destination;
            }
            catch
            {
                MessageBox.Show("Не удалось сохранить изображение в AppDock.", "AppDock",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return "";
            }
        }

        private void EnsureDefaultInterfaceImages()
        {
            try
            {
                if (string.IsNullOrEmpty(settingsImagePath) || !File.Exists(settingsImagePath))
                {
                    string path = Path.Combine(iconsFolder, "default_gear.png");
                    DownloadIfMissing(DefaultGearUrl, path);
                    if (File.Exists(path)) settingsImagePath = path;
                }

                if (string.IsNullOrEmpty(closeImagePath) || !File.Exists(closeImagePath))
                {
                    string path = Path.Combine(iconsFolder, "default_close.png");
                    DownloadIfMissing(DefaultCloseUrl, path);
                    if (File.Exists(path)) closeImagePath = path;
                }
            }
            catch { }
        }

        private void DownloadIfMissing(string url, string destination)
        {
            if (File.Exists(destination)) return;

            try
            {
                using (WebClient client = new WebClient())
                {
                    client.Headers.Add("User-Agent", "AppDock/1.0");
                    client.DownloadFile(url, destination);
                }
            }
            catch { }
        }

        private void RefreshInterfaceImages()
        {
            BitmapImage gear = LoadImage(settingsImagePath);
            BitmapImage close = LoadImage(closeImagePath);

            SettingsButtonImage.Source = gear;
            CloseButtonImage.Source = close;
            GearPreview.Source = gear;
            ClosePreview.Source = close;

            if (gear == null) SettingsButton.Content = "⚙";
            else SettingsButton.Content = SettingsButtonImage;

            if (close == null) CloseButton.Content = "×";
            else CloseButton.Content = CloseButtonImage;
        }

        private void SaveData()
        {
            try
            {
                string directory = Path.GetDirectoryName(saveFile);
                Directory.CreateDirectory(directory);

                AppData data = new AppData
                {
                    FolderName = FolderNameBox?.Text ?? "Мои приложения",
                    Opacity = OpacitySlider?.Value ?? 0.87,
                    Color = currentColor,
                    SettingsImagePath = settingsImagePath,
                    CloseImagePath = closeImagePath,
                    CustomIcons = new Dictionary<string, string>(customIcons, StringComparer.OrdinalIgnoreCase),
                    Apps = new List<AppItem>()
                };

                foreach (Button button in AppsPanel.Children.OfType<Button>())
                {
                    AppButtonData buttonData = GetButtonData(button);
                    if (buttonData == null || string.IsNullOrEmpty(buttonData.ApplicationPath)) continue;

                    string name = "";
                    if (button.Content is StackPanel panel)
                    {
                        TextBlock text = panel.Children.OfType<TextBlock>().FirstOrDefault();
                        if (text != null) name = text.Text;
                    }

                    data.Apps.Add(new AppItem
                    {
                        Path = buttonData.ApplicationPath,
                        Name = name,
                        Row = Grid.GetRow(button),
                        Column = Grid.GetColumn(button),
                        ShortcutPath = buttonData.ShortcutPath,
                        StoredShortcutPath = buttonData.StoredShortcutPath,
                        HiddenByAppDock = buttonData.HiddenByAppDock,
                        OriginalAttributes = buttonData.OriginalAttributes
                    });
                }

                string json = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(saveFile, json);
            }
            catch { }
        }

        private void LoadData()
        {
            try
            {
                if (!File.Exists(saveFile)) return;

                string json = File.ReadAllText(saveFile);
                AppData data = JsonSerializer.Deserialize<AppData>(json);
                if (data == null) return;

                FolderNameBox.Text = data.FolderName;
                Title = data.FolderName;
                OpacitySlider.Value = data.Opacity;
                currentColor = string.IsNullOrEmpty(data.Color) ? "#202020" : data.Color;

                if (!string.IsNullOrEmpty(data.SettingsImagePath)) settingsImagePath = data.SettingsImagePath;
                if (!string.IsNullOrEmpty(data.CloseImagePath)) closeImagePath = data.CloseImagePath;

                customIcons = data.CustomIcons ?? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

                Color color = (Color)ColorConverter.ConvertFromString(currentColor);
                MainBorder.Background = new SolidColorBrush(color);

                foreach (AppItem app in data.Apps ?? new List<AppItem>())
                {
                    AddApplicationFromData(app.Path, app.Name, app.Row, app.Column,
                        app.ShortcutPath, app.StoredShortcutPath,
                        app.HiddenByAppDock, app.OriginalAttributes);
                }
            }
            catch { }
        }

        private void CloseApp_Click(object sender, RoutedEventArgs e)
        {
            SaveData();
            Close();
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            SaveData();
            base.OnClosing(e);
        }
    }
}
